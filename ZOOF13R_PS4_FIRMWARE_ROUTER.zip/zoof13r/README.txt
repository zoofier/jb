ZOOF13R PS4 HOST - firmware-aware legacy build

This build fixes PS4 firmware detection and separates 13.52 from 14.00.

Detection accepts documented PS4 UA forms such as:
  PlayStation 4/13.52
  PlayStation 4/13.52.000
  PS4 Update (13.52)

For 13.02-13.52, the host offers the public WebKitty chain, whose published support table lists Slopkit + Relapse for 13.02-13.52.
For 14.00, this package remains a diagnostic/staging host and does not claim a jailbreak unless a verified 14.00 exploit module is supplied.

Important: a web page cannot independently prove the installed system version beyond what the browser exposes in its user-agent. The host therefore displays the exact UA and a parsed firmware value.
